﻿CREATE DATABASE ciber;

CREATE TABLE  empleados(
clave_empleado varchar(10) primary key,
nombre varchar(40),
direccion varchar(50),
edad int,
telefono varchar(13),
status  varchar(10));

CREATE TABLE  equipos(
clave_equipo serial primary key,
nombre_equipo varchar(10),
tipo_sistema  varchar(10),
tamanio_ram  varchar(10),
procesador varchar(15),
status  varchar(10),
renta varchar(10));

CREATE TABLE  servicios(
clave_servicio serial primary key,
nombre_servicio varchar(20),
descripcion_servicio varchar(30),
precio  int null);

CREATE TABLE  renta_equipo(
registro serial primary key,
clave_empleado varchar(10),
clave_equipo  int null,
fecha date,
incial time,
final time,
tiempo time,
precio  double precision,
status  varchar(10),
CONSTRAINT fk_renta_empleado FOREIGN KEY (clave_empleado) REFERENCES empleados (clave_empleado),
CONSTRAINT fk_renta_equipo FOREIGN KEY (clave_equipo) REFERENCES equipos (clave_equipo));

CREATE TABLE  servicios_extra(
registro serial primary key,
clave_empleado varchar(10),
clave_servicio int,
nombre_servicio varchar(20),
precio int,
cantidad int,
total int,
fecha date ,
hora  time ,
CONSTRAINT fk_servicios_empleado FOREIGN KEY (clave_empleado) REFERENCES empleados (clave_empleado),
CONSTRAINT fk_servicios_servicio FOREIGN KEY (clave_servicio) REFERENCES servicios (clave_servicio));

CREATE TABLE usuarios(
no_usuario serial primary key,
nombre_usuario varchar(10),
password varchar(10),
CONSTRAINT fk_usuarios_empleado FOREIGN KEY (nombre_usuario) REFERENCES empleados (clave_empleado));


