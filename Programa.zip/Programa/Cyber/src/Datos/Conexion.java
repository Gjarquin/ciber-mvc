/*
Clase para conectar la base de datos al sistema 
Autor:@Gil Jarquin
*/
package Datos;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Conexion {
    private static  Conexion c=null;
    public Connection conectar=null;
    public static Conexion getInstance()
        {    
         if(c==null)
             c=new Conexion();
            return c;
        }
        
        private  Conexion(){
        try {
            String url="jdbc:postgresql://localhost/ciber";
            String driver="org.postgresql.Driver";
            Class.forName(driver);            
            conectar=DriverManager.getConnection(url,"postgres","1234567890"); 
            } catch (ClassNotFoundException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
            }              
        }
    
}//Finaliza la clase Conexion
