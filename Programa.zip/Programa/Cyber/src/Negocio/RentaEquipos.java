package Negocio;

import Datos.Conexion;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;


public class RentaEquipos {
    private int registro;
    private String clave_empleado;
    private int  clave_equipo;
    private Date fecha; 
    private Time  hora_inicio;
    private Time  hora_final;
    private Time  tiempo;
    private double precio;
    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getRegistro() {
        return registro;
    }

    public void setRegistro(int registro) {
        this.registro = registro;
    }

    public String getClave_empleado() {
        return clave_empleado;
    }

    public void setClave_empleado(String clave_empleado) {
        this.clave_empleado = clave_empleado;
    }

    public int getClave_equipo() {
        return clave_equipo;
    }

    public void setClave_equipo(int clave_equipo) {
        this.clave_equipo = clave_equipo;
    }
     
    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Time getHora_inicio() {
        return hora_inicio;
    }

    public void setHora_inicio(Time hora_inicio) {
        this.hora_inicio = hora_inicio;
    }

    public Time getHora_final() {
        return hora_final;
    }

    public void setHora_final(Time hora_final) {
        this.hora_final = hora_final;
    }

    public Time getTiempo() {
        return tiempo;
    }

    public void setTiempo(Time tiempo) {
        this.tiempo = tiempo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    private  Conexion con=Conexion.getInstance();  
    private  Statement  sentencia;
    private  ResultSet res=null;
     public  boolean registrar_Renta(JTextField tcvEm,JTextField tcvEquipo,String status){
       boolean recuperar;
        try {
           RentaEquipos renta=new RentaEquipos(); 
           renta.setClave_empleado(tcvEm.getText());
           renta.setClave_equipo(Integer.parseInt(tcvEquipo.getText())); 
           String sql="insert into renta_equipo(clave_empleado,clave_equipo,fecha,incial,status)"+"values('" +renta.getClave_empleado()+"','"+renta.getClave_equipo()+ "',current_date,current_time,'"+status+"');";          
           sentencia = con.conectar.createStatement();  
           sentencia.execute(sql);   
           Equipos equipo=new Equipos();
           equipo.Modificar_Equipo(tcvEquipo,status);
          recuperar =true;
       } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"SE DUPLICO CLAVE EN BASE DE DATOS");
            recuperar= false;
       }
        return  recuperar ;
    } 
     public boolean registrar_Renta(JTextField tregistro,JTextField tequipo,JTextField tpago,String status){
       boolean recuperar;
        try {
           RentaEquipos renta=new RentaEquipos(); 
           renta.setRegistro(Integer.parseInt(tregistro.getText()));
           renta.setClave_equipo(Integer.parseInt(tequipo.getText()));
           renta.setPrecio(Double.parseDouble(tpago.getText()));
           renta.setStatus(status); 
           String sql="update renta_equipo set precio='"+renta.getPrecio()+"' ,status='"+renta.getStatus()+"' where registro='"+renta.getRegistro()+"';";          
           sentencia = con.conectar.createStatement();  
           sentencia.execute(sql);   
           Equipos equipo=new Equipos();
           equipo.Modificar_Equipo(tequipo,"LIBRE");
          recuperar =true;
       } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"SE DUPLICO CLAVE EN BASE DE DATOS");
            recuperar= false;
       }
        return  recuperar ;
    }
     public  double consultar_Renta_Equipos(Time tiempo){
      Servicios servicio=new Servicios(); 
        double precio=Double.valueOf(servicio.consultar_Servicios(1));
        double total=0;
        double precio2=precio/2;
        int hora=tiempo.getHours();
        int minutos=tiempo.getMinutes();
        total=(hora*precio);
        if(minutos<=30){
            total=total+precio2;
        }else{
            total=total+precio;
        }
     return total;
     }
     
     public   DefaultTableModel consultar_Renta_Equipos(){ 
        DefaultTableModel datamodel = null;     
          try {   
              sentencia = con.conectar.createStatement();  
               sentencia.execute("UPDATE renta_equipo SET final=now(), tiempo=(now()- incial) where status='OCUPADA';");
               res=sentencia.executeQuery("SELECT  * FROM renta_equipo WHERE status='OCUPADA';");
              Vector columnas=new Vector();
            columnas.addElement("REGISTRO");
            columnas.addElement("CLAVE EMPLEADO"); 
             columnas.addElement("CLAVE EQUIPO");
            columnas.addElement("FECHA"); 
             columnas.addElement("T_INICIAL");
            columnas.addElement("T_FINAL"); 
             columnas.addElement("TIEMPO");
            columnas.addElement("PRECIO"); 
             columnas.addElement("STATUS"); 
            Vector rows=new Vector();
            while(res.next()){ 
                int registro=res.getInt("registro");
                String cv_empleado=res.getString("clave_empleado");  
                int cv_equipo=res.getInt("clave_equipo");
                Date fecha=res.getDate("fecha");
                Time t_inicial=res.getTime("incial");
                Time t_final=res.getTime("final");
                Time t_tiempo=res.getTime("tiempo");
                double precio=res.getDouble("precio");
                String status=res.getString("status");
                Vector filas=new Vector(); 
                filas.addElement(registro);
                filas.addElement(cv_empleado);
                filas.addElement(cv_equipo);
                filas.addElement(fecha);
                filas.addElement(t_inicial);
                filas.addElement(t_final);
                filas.addElement(t_tiempo);
                filas.addElement(precio);
                filas.addElement(status);         
                rows.addElement(filas);
            } 
           datamodel=new DefaultTableModel(rows,columnas);         
        } catch (SQLException ex) {
            Logger.getLogger(RentaEquipos.class.getName()).log(Level.SEVERE, null, ex);
        }
        return datamodel;
    }

}
