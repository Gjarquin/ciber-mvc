package Negocio;
 
import Datos.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;



public class Empleados {
   private String  clave_empleado;    
    private String nombre;    
    private String  direccion;
    private int  edad;
    private String  telefono;
    private String status;

    public String getClave_empleado() {
        return clave_empleado;
    }

    public void setClave_empleado(String clave_empleado) {
        this.clave_empleado = clave_empleado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Conexion getCon() {
        return con;
    }

    public void setCon(Conexion con) {
        this.con = con;
    }

    public Statement getSentencia() {
        return sentencia;
    }

    public void setSentencia(Statement sentencia) {
        this.sentencia = sentencia;
    }

    public ResultSet getRes() {
        return res;
    }

    public void setRes(ResultSet res) {
        this.res = res;
    }
 
    private  Conexion con=Conexion.getInstance();  
    private  Statement  sentencia;
    private  ResultSet res;
    public  boolean registrar_Empleado(JTextField tclave,JTextField tnombre,JTextField tdireccion,JTextField tedad,JTextField ttelefono,JComboBox tstatus){
       boolean recuperar;
        try {
           Empleados empleado=new Empleados();
           empleado.setClave_empleado(tclave.getText());
           empleado.setNombre(tnombre.getText());
           empleado.setDireccion(tdireccion.getText());
           empleado.setEdad(Integer.parseInt(tedad.getText()));
           empleado.setTelefono(ttelefono.getText());  
           empleado.setStatus(String.valueOf(tstatus.getSelectedItem()));
           String sql="insert into empleados(clave_empleado,nombre,direccion,edad,telefono,status)"+"values('" +empleado.getClave_empleado()+"','"+ empleado.getNombre()+ "','"+ empleado.getDireccion()+ "','"+ empleado.getEdad()+"','"+ empleado.getTelefono()+ "','"+empleado.getStatus()+"');";          
           sentencia = con.conectar.createStatement();  
           sentencia.execute(sql);           
          recuperar =true;
       } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"SE DUPLICO CLAVE EN BASE DE DATOS");
            recuperar= false;
       }
        return  recuperar ;
    }
    public  boolean modificar_Empleado(JTextField tclave,JTextField tnombre,JTextField tdireccion,JTextField tedad,JTextField ttelefono){
       boolean recuperar;
        try {
           Empleados empleado=new Empleados();
           empleado.setClave_empleado(tclave.getText());
           empleado.setNombre(tnombre.getText());
           empleado.setDireccion(tdireccion.getText());
           empleado.setEdad(Integer.parseInt(tedad.getText()));
           empleado.setTelefono(ttelefono.getText());    
           String sql="update empleados set nombre='"+empleado.getNombre()+"',direccion='"+empleado.getDireccion()+"',edad='"+ empleado.getEdad()+"',telefono='"+ empleado.getTelefono()+"' where clave_empleado='"+empleado.getClave_empleado()+"';";          
           sentencia = con.conectar.createStatement();  
           sentencia.execute(sql);           
          recuperar =true;
       } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"ERROR EN BASE DE DATOS");
            recuperar= false;
       }
        return  recuperar ;
    }
    public   boolean Baja_Empleado(JTextField tclave,JComboBox tstatus){
       boolean recuperar;
        try {
           Empleados empleado=new Empleados();
           empleado.setClave_empleado(tclave.getText());   
            empleado.setStatus(String.valueOf(tstatus.getSelectedItem()));
            Usuarios usuario=new Usuarios();
           usuario.eliminar_usuario(tclave,String.valueOf(tstatus.getSelectedItem()));
           String sql="update empleados set status='"+empleado.getStatus()+"'  where clave_empleado='"+empleado.getClave_empleado()+"';";          
           sentencia = con.conectar.createStatement();  
           sentencia.execute(sql);  
           
          recuperar =true;
       } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"ERROR EN BASE DE DATOS");
            recuperar= false;
       }
        return  recuperar ;
    }
    public  DefaultTableModel consultar_empleados(){ 
        DefaultTableModel datamodel = null;     
          try {        
            sentencia = con.conectar.createStatement();             
            res=sentencia.executeQuery("select * from empleados where status='ACTIVO'; ");
            Vector columnas=new Vector();
            columnas.addElement("CLAVE");
            columnas.addElement("NOMBRE");
            columnas.addElement("DIRECCION");
            columnas.addElement("EDAD");
            columnas.addElement("TELEFONO"); 
            Vector rows=new Vector();
            while(res.next()){ 
                String clave=res.getString("clave_empleado");
                String nombre=res.getString("nombre");  
                String direccion=res.getString("direccion");
                String edad=res.getString("edad");
                String telefono=res.getString("telefono");
                Vector filas=new Vector(); 
                filas.addElement(clave);
                filas.addElement(nombre);   
                filas.addElement(direccion);
                filas.addElement(edad);
                filas.addElement(telefono);
                rows.addElement(filas);
            } 
           datamodel=new DefaultTableModel(rows,columnas);         
        } catch (SQLException ex) {
            Logger.getLogger(Empleados.class.getName()).log(Level.SEVERE, null, ex);
        }
        return datamodel;
    }
     public  DefaultTableModel todos_empleados(){ 
        DefaultTableModel datamodel = null;     
          try {        
            sentencia = con.conectar.createStatement();             
            res=sentencia.executeQuery("select * from empleados; ");
            Vector columnas=new Vector();
            columnas.addElement("CLAVE");
            columnas.addElement("NOMBRE");
            columnas.addElement("DIRECCION");
            columnas.addElement("EDAD");
            columnas.addElement("TELEFONO"); 
             columnas.addElement("STATUS"); 
            Vector rows=new Vector();
            while(res.next()){ 
                String clave=res.getString("clave_empleado");
                String nombre=res.getString("nombre");  
                String direccion=res.getString("direccion");
                String edad=res.getString("edad");
                String telefono=res.getString("telefono");
                String status=res.getString("status");
                Vector filas=new Vector(); 
                filas.addElement(clave);
                filas.addElement(nombre);   
                filas.addElement(direccion);
                filas.addElement(edad);
                filas.addElement(telefono);
                filas.addElement(status);
                rows.addElement(filas);
            } 
           datamodel=new DefaultTableModel(rows,columnas);         
        } catch (SQLException ex) {
            Logger.getLogger(Empleados.class.getName()).log(Level.SEVERE, null, ex);
        }
        return datamodel;
    }
    public   DefaultTableModel consultar_empleados(JTextField cve){ 
        DefaultTableModel datamodel = null;     
          try {  
           sentencia = con.conectar.createStatement();  
            res=sentencia.executeQuery("select * from empleados where clave_empleado='"+cve.getText()+"' and status='ACTIVO'; ");
            Vector columnas=new Vector();
            columnas.addElement("CLAVE");
            columnas.addElement("NOMBRE");
            columnas.addElement("DIRECCION");
            columnas.addElement("EDAD");
            columnas.addElement("TELEFONO"); 
            Vector rows=new Vector();
            while(res.next()){ 
                String clave=res.getString("clave_empleado");
                String nombre=res.getString("nombre");  
                String direccion=res.getString("direccion");
                String edad=res.getString("edad");
                String telefono=res.getString("telefono");
                Vector filas=new Vector(); 
                filas.addElement(clave);
                filas.addElement(nombre);   
                filas.addElement(direccion);
                filas.addElement(edad);
                filas.addElement(telefono);
                rows.addElement(filas);
            } 
           datamodel=new DefaultTableModel(rows,columnas);         
        } catch (SQLException ex) {
            Logger.getLogger(Empleados.class.getName()).log(Level.SEVERE, null, ex);
        }
        return datamodel;
    }    
}
