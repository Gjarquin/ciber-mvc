package Negocio;
 
import Datos.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;



public class Equipos {
    private int clave_equipo;    
    private String nombre_equipo;    
    private String tipo_sistema;
    private String tamanio_ram;
    private String procesador;
    private String status;
    private String renta;

    public int getClave_equipo() {
        return clave_equipo;
    }

    public void setClave_equipo(int clave_equipo) {
        this.clave_equipo = clave_equipo;
    }

    public String getNombre_equipo() {
        return nombre_equipo;
    }

    public void setNombre_equipo(String nombre_equipo) {
        this.nombre_equipo = nombre_equipo;
    }

    public String getTipo_sistema() {
        return tipo_sistema;
    }

    public void setTipo_sistema(String tipo_sistema) {
        this.tipo_sistema = tipo_sistema;
    }

    public String getTamanio_ram() {
        return tamanio_ram;
    }

    public void setTamanio_ram(String tamanio_ram) {
        this.tamanio_ram = tamanio_ram;
    }

    public String getProcesador() {
        return procesador;
    }

    public void setProcesador(String procesador) {
        this.procesador = procesador;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRenta() {
        return renta;
    }

    public void setRenta(String renta) {
        this.renta = renta;
    }

    private  Conexion con=Conexion.getInstance();  
    private  Statement  sentencia;
    private  ResultSet res;
     public  boolean registrar_Equipo(JTextField tnombre,JTextField ttiposistema,JTextField tram,JTextField tprocesador,JComboBox tstatus){
       boolean recuperar;
        try {
           Equipos equipo=new Equipos(); 
           equipo.setNombre_equipo(tnombre.getText());
           equipo.setTipo_sistema(ttiposistema.getText());
           equipo.setTamanio_ram(tram.getText());
           equipo.setProcesador(tprocesador.getText());
           equipo.setStatus(String.valueOf(tstatus.getSelectedItem())); 
           String sql="insert into equipos(nombre_equipo,tipo_sistema,tamanio_ram,procesador,status,renta)"+"values('" +equipo.getNombre_equipo()+"','"+equipo.getTipo_sistema()+ "','"+ equipo.getTamanio_ram()+ "','"+ equipo.getProcesador()+"','"+ equipo.getStatus()+"','LIBRE');";          
           sentencia = con.conectar.createStatement();  
           sentencia.execute(sql);           
          recuperar =true;
       } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"SE DUPLICO CLAVE EN BASE DE DATOS");
            recuperar= false;
       }
        return  recuperar ;
    }
    
    public  boolean Modificar_Equipo(JTextField tclave,JTextField tnombre,JTextField ttiposistema,JTextField tram,JTextField tprocesador){
       boolean recuperar;
        try {
           Equipos equipo=new Equipos(); 
           equipo.setClave_equipo(Integer.parseInt(tclave.getText()));
           equipo.setNombre_equipo(tnombre.getText());
           equipo.setTipo_sistema(ttiposistema.getText());
           equipo.setTamanio_ram(tram.getText());
           equipo.setProcesador(tprocesador.getText());    
           String sql="update equipos set nombre_equipo='"+equipo.getNombre_equipo()+"', tipo_sistema='"+equipo.getTipo_sistema()+"', tamanio_ram='"+ equipo.getTamanio_ram()+ "', procesador='"+ equipo.getProcesador()+"' where clave_equipo='"+equipo.getClave_equipo()+"';";          
           sentencia = con.conectar.createStatement();  
           sentencia.execute(sql);           
          recuperar =true;
       } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"ERROR EN  BASE DE DATOS");
            recuperar= false;
       }
        return  recuperar ;
    }
    
    public boolean Modificar_Equipo(JTextField tclave,JComboBox tstatus){
       boolean recuperar;
        try {
           Equipos equipo=new Equipos(); 
           equipo.setClave_equipo(Integer.parseInt(tclave.getText()));
          equipo.setStatus(String.valueOf(tstatus.getSelectedItem()));    
           String sql="update equipos set status='"+ equipo.getStatus()+"' where clave_equipo='"+equipo.getClave_equipo()+"';";          
           sentencia = con.conectar.createStatement();  
           sentencia.execute(sql);           
          recuperar =true;
       } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"ERROR EN  BASE DE DATOS");
            recuperar= false;
       }
        return  recuperar ;
    }
    
    public boolean Modificar_Equipo(JTextField tclave,String status){
       boolean recuperar;
        try {
           Equipos equipo=new Equipos(); 
           equipo.setClave_equipo(Integer.parseInt(tclave.getText()));
          equipo.setRenta(status);    
           String sql="update equipos set renta='"+ equipo.getRenta()+"' where clave_equipo='"+equipo.getClave_equipo()+"';";          
           sentencia = con.conectar.createStatement();  
           sentencia.execute(sql);           
          recuperar =true;
       } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"ERROR EN  BASE DE DATOS");
            recuperar= false;
       }
        return  recuperar ;
    }
    
    
    public DefaultTableModel consultar_Equipos(){ 
        DefaultTableModel datamodel = null;     
          try {  
            sentencia = con.conectar.createStatement();  
            res=sentencia.executeQuery("select * from equipos; ");
            Vector columnas=new Vector();
            columnas.addElement("CLAVE");
            columnas.addElement("NOMBRE DE EQUIPO");
            columnas.addElement("SISTEMA");
            columnas.addElement("RAM");
            columnas.addElement("PRECESADOR"); 
            columnas.addElement("STATUS"); 
            Vector rows=new Vector();
            while(res.next()){ 
                int clave=res.getInt("clave_equipo");
                String nombre=res.getString("nombre_equipo");  
                String sistema=res.getString("tipo_sistema");
                String ram=res.getString("tamanio_ram");
                String procesador=res.getString("procesador");
                String status=res.getString("status");
                Vector filas=new Vector(); 
                filas.addElement(clave);
                filas.addElement(nombre);   
                filas.addElement(sistema);
                filas.addElement(ram);
                filas.addElement(procesador);
                filas.addElement(status);
                rows.addElement(filas);
            } 
           datamodel=new DefaultTableModel(rows,columnas);         
        } catch (SQLException ex) {
            Logger.getLogger(Equipos.class.getName()).log(Level.SEVERE, null, ex);
        }
        return datamodel;
    }
     public  DefaultTableModel consultar_Equipos_libres(){ 
        DefaultTableModel datamodel = null;     
          try {    
            sentencia = con.conectar.createStatement();  
            res=sentencia.executeQuery("SELECT  equipos.clave_equipo as clave,equipos.renta as equipo FROM equipos  WHERE equipos.renta='LIBRE' and equipos.status='ACTIVA';");
            Vector columnas=new Vector();
            columnas.addElement("CLAVE EQUIPO");
            columnas.addElement("ESTADO DE RENTA"); 
            Vector rows=new Vector();
            while(res.next()){ 
                int clave=res.getInt("clave");
                String estado_renta=res.getString("equipo");   
                Vector filas=new Vector(); 
                filas.addElement(clave);
                filas.addElement(estado_renta);
                rows.addElement(filas);
            } 
           datamodel=new DefaultTableModel(rows,columnas);         
        } catch (SQLException ex) {
            Logger.getLogger(Equipos.class.getName()).log(Level.SEVERE, null, ex);
        }
        return datamodel;
    }
 
   }
