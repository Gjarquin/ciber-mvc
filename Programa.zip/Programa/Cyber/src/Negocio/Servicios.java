package Negocio;

import Datos.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;


public class Servicios {
    private int clave_servicio;
    private String nombre_servicio;
    private String descripcion_servicio;
    private int precio;

    public int getClave_servicio() {
        return clave_servicio;
    }

    public void setClave_servicio(int clave_servicio) {
        this.clave_servicio = clave_servicio;
    }

    public String getNombre_servicio() {
        return nombre_servicio;
    }

    public void setNombre_servicio(String nombre_servicio) {
        this.nombre_servicio = nombre_servicio;
    }

    public String getDescripcion_servicio() {
        return descripcion_servicio;
    }

    public void setDescripcion_servicio(String descripcion_servicio) {
        this.descripcion_servicio = descripcion_servicio;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }
    private  Conexion con=Conexion.getInstance();  
    private  Statement  sentencia;
    private  ResultSet res=null;
     public  boolean registrar_Servicio(JTextField tnombre,JTextField tdescripcion,JTextField tprecio){
       boolean recuperar;
        try {
           Servicios servicio=new Servicios(); 
           servicio.setNombre_servicio(tnombre.getText());
           servicio.setDescripcion_servicio(tdescripcion.getText());
           servicio.setPrecio(Integer.parseInt(tprecio.getText()));       
           String sql="insert into servicios(nombre_servicio,descripcion_servicio,precio)"+"values('" +servicio.getNombre_servicio()+"','"+servicio.getDescripcion_servicio()+ "','"+ servicio.getPrecio()+ "');";          
           sentencia = con.conectar.createStatement();  
           sentencia.execute(sql);           
          recuperar =true;
       } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"SE DUPLICO CLAVE EN BASE DE DATOS");
            recuperar= false;
       }
        return  recuperar ;
    }
     public  boolean modificar_Servicio(JTextField tclave,JTextField tnombre,JTextField tdescripcion,JTextField tprecio){
       boolean recuperar;
        try {
           Servicios servicio=new Servicios(); 
           servicio.setClave_servicio(Integer.parseInt(tclave.getText()));
           servicio.setNombre_servicio(tnombre.getText());
           servicio.setDescripcion_servicio(tdescripcion.getText());
           servicio.setPrecio(Integer.parseInt(tprecio.getText()));    
           String sql="update  servicios set nombre_servicio='" +servicio.getNombre_servicio()+"',descripcion_servicio='"+servicio.getDescripcion_servicio()+ "',precio='"+servicio.getPrecio()+"' where clave_servicio='"+servicio.getClave_servicio()+"'  ;";          
           sentencia = con.conectar.createStatement();  
           sentencia.execute(sql);           
          recuperar =true;
       } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"SE DUPLICO CLAVE EN BASE DE DATOS");
            recuperar= false;
       }
        return  recuperar ;
    }
     
      public  DefaultTableModel consultar_Servicios(){ 
        DefaultTableModel datamodel = null;     
          try {                 
            sentencia = con.conectar.createStatement();  
            res=sentencia.executeQuery("select * from servicios;");
            Vector columnas=new Vector();
            columnas.addElement("CLAVE");
            columnas.addElement("NOMBRE SERVICIO");
            columnas.addElement("DESCRIPCION");
            columnas.addElement("PRECIO");
            Vector rows=new Vector();
            while(res.next()){ 
                String clave=res.getString("clave_servicio");
                String nombre=res.getString("nombre_servicio");  
                String descipcion=res.getString("descripcion_servicio");
                String precio=res.getString("precio");
                Vector filas=new Vector(); 
                filas.addElement(clave);
                filas.addElement(nombre);   
                filas.addElement(descipcion);
                filas.addElement(precio);
                rows.addElement(filas);
            } 
           datamodel=new DefaultTableModel(rows,columnas);         
        } catch (SQLException ex) {
            Logger.getLogger(Servicios.class.getName()).log(Level.SEVERE, null, ex);
        }
        return datamodel;
    }
      public   DefaultTableModel consultar_Servicios(JTextField cv){ 
        DefaultTableModel datamodel = null;   
        int cve=Integer.parseInt(cv.getText());
          try { 
              sentencia = con.conectar.createStatement();  
               res=sentencia.executeQuery("select * from servicios where clave_servicio='"+cve+"';");
              Vector columnas=new Vector();
            columnas.addElement("CLAVE");
            columnas.addElement("NOMBRE SERVICIO");
            columnas.addElement("DESCRIPCION");
            columnas.addElement("PRECIO");
            Vector rows=new Vector();
            while(res.next()){ 
                String clave=res.getString("clave_servicio");
                String nombre=res.getString("nombre_servicio");  
                String descipcion=res.getString("descripcion_servicio");
                String precio=res.getString("precio");
                Vector filas=new Vector(); 
                filas.addElement(clave);
                filas.addElement(nombre);   
                filas.addElement(descipcion);
                filas.addElement(precio);
                rows.addElement(filas);
            } 
           datamodel=new DefaultTableModel(rows,columnas);         
        } catch (SQLException ex) {
            Logger.getLogger(Servicios.class.getName()).log(Level.SEVERE, null, ex);
        }
        return datamodel;
    }
      public  int consultar_Servicios(int clave){      
        int precio=0;
          try { 
             sentencia = con.conectar.createStatement();  
             res=sentencia.executeQuery("select precio from servicios where clave_servicio='"+clave+"';");       
            while (res.next()) {
                precio=res.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Servicios.class.getName()).log(Level.SEVERE, null, ex);
        }
         return precio;
    }
    
}
