 
package Negocio;

import Datos.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement; 
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField; 
import javax.swing.table.DefaultTableModel;


public class Usuarios {
  private int no_usuario;
  private String nombre_usuario;
  private String password;

    public int getNo_usuario() {
        return no_usuario;
    }

    public void setNo_usuario(int no_usuario) {
        this.no_usuario = no_usuario;
    }

  

    public String getNombre_usuario() {
        return nombre_usuario;
    }

    public void setNombre_usuario(String nombre_usuario) {
        this.nombre_usuario = nombre_usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

     private  Conexion con=Conexion.getInstance();  
    private  Statement  sentencia;         
   public boolean registrar_usuario(JTextField t_nombre,JPasswordField t_pass){
       boolean recuperar;
        try {
           Usuarios user=new Usuarios(); 
           user.setNombre_usuario(t_nombre.getText());
           user.setPassword(t_pass.getText()); 
           sentencia = con.conectar.createStatement();      
           String sql="insert into usuarios(nombre_usuario,password)"+"values('" +user.getNombre_usuario()+"','"+user.getPassword()+"');";          
           sentencia.execute(sql);           
          recuperar =true;
       } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"SE DUPLICO CLAVE EN BASE DE DATOS");
            recuperar= false;
       }
        return  recuperar ;
    }
   public boolean modificar_usuario(JTextField no_usuario,JPasswordField t_pass){
       boolean recuperar;
        try {
           Usuarios user=new Usuarios(); 
           user.setNo_usuario(Integer.parseInt(no_usuario.getText()));
           user.setPassword(t_pass.getText());   
           String sql="update  usuarios set password='"+user.getPassword()+"' where no_usuario='"+user.getNo_usuario()+"';";          
           sentencia = con.conectar.createStatement();  
           sentencia.execute(sql);           
          recuperar =true;
       } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"SE DUPLICO CLAVE EN BASE DE DATOS");
            recuperar= false;
       }
        return  recuperar ;
    }
    public void eliminar_usuario(JTextField  cv_usuario,String estado){     
        try {
            if(estado =="BAJA"){
           Usuarios user=new Usuarios(); 
           user.setNombre_usuario(cv_usuario.getText());   
           String sql="delete  from usuarios  where nombre_usuario='"+user.getNombre_usuario()+"';";          
           sentencia = con.conectar.createStatement();  
           sentencia.execute(sql);           
            }
       } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"SE DUPLICO CLAVE EN BASE DE DATOS");
            
       } 
    }
   public  DefaultTableModel consultar_usuarios(){ 
        DefaultTableModel datamodel = null;
        try {    
          sentencia = con.conectar.createStatement();  
          ResultSet res=sentencia.executeQuery("select * from usuarios;");
          Vector columnas=new Vector();
          columnas.addElement("CV REGISTRO");
          columnas.addElement("CV EMPLEADO"); 
          Vector rows=new Vector();
          while(res.next()){
              Vector filas=new Vector();
              filas.addElement(res.getInt("no_usuario"));
              filas.addElement(res.getString("nombre_usuario")); 
              rows.addElement(filas);
          }
          datamodel=new DefaultTableModel(rows,columnas);            
      } catch (SQLException ex) {
          Logger.getLogger(Usuarios.class.getName()).log(Level.SEVERE, null, ex);
      }  
      return datamodel;
    }
   
   public boolean consultar_usuarios(JTextField usuario, JPasswordField pass){
        try {    
             Usuarios user=new Usuarios(); 
             user.setNombre_usuario(usuario.getText());
             user.setPassword(pass.getText());
            sentencia = con.conectar.createStatement();  
           ResultSet res=sentencia.executeQuery("SELECT * FROM usuarios WHERE nombre_usuario='"+user.getNombre_usuario()+"' AND password='"+user.getPassword()+"'"); 
            if( res.next()){       
                return true;        
            }else{
                return false;      
            }        
        } catch (SQLException ex) {
            Logger.getLogger(Usuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
        return  false;
    }  
}
