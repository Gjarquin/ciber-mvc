
package Negocio;

import Datos.Conexion;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;


public class ServiciosExtras {
    
    private int  registro;   
    private String clave_empleado; 
    private int  clave_servicio;      
    private String  nombre_servicio;
    private int  precio;    
     private int  cantidad; 
    private int  total;
    private Date   fecha;
    private Time   hora;   

    public int getRegistro() {
        return registro;
    }

    public void setRegistro(int registro) {
        this.registro = registro;
    }

    public String getClave_empleado() {
        return clave_empleado;
    }

    public void setClave_empleado(String clave_empleado) {
        this.clave_empleado = clave_empleado;
    }

    public int getClave_servicio() {
        return clave_servicio;
    }

    public void setClave_servicio(int clave_servicio) {
        this.clave_servicio = clave_servicio;
    }

    public String getNombre_servicio() {
        return nombre_servicio;
    }

    public void setNombre_servicio(String nombre_servicio) {
        this.nombre_servicio = nombre_servicio;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Time getHora() {
        return hora;
    }

    public void setHora(Time hora) {
        this.hora = hora;
    }
     private  Conexion con=Conexion.getInstance();  
    private  Statement  sentencia;
    private  ResultSet res=null;   
    public  boolean registrar_Servicio(JTextField t_empleado,JTextField t_servicio,JTextField t_nomservicio,JTextField t_cantidad,JTextField t_precio,JTextField t_total){
       boolean recuperar;
        try {
           ServiciosExtras servicio=new ServiciosExtras(); 
           servicio.setClave_empleado(t_empleado.getText());
           servicio.setClave_servicio(Integer.parseInt(t_servicio.getText()));
           servicio.setNombre_servicio(t_nomservicio.getText());
           servicio.setPrecio(Integer.parseInt(t_precio.getText()));
           servicio.setCantidad(Integer.parseInt(t_cantidad.getText()));
           servicio.setTotal(Integer.parseInt(t_total.getText()));       
           String sql="insert into servicios_extra(clave_empleado,clave_servicio,nombre_servicio,precio,cantidad,total,fecha,hora)"+"values('"+servicio.getClave_empleado()+"','"+servicio.getClave_servicio()+"','"+servicio.getNombre_servicio()+"','"+servicio.getPrecio()+"','"+servicio.getCantidad()+"','"+servicio.getTotal()+"',current_date,current_time);";          
           sentencia = con.conectar.createStatement();  
           sentencia.execute(sql);           
          recuperar =true;
       } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"SE DUPLICO CLAVE EN BASE DE DATOS");
            recuperar= false;
       }
        return  recuperar ;
    }

     public   DefaultTableModel consultar_ServiciosExtra(){ 
        DefaultTableModel datamodel = null;     
          try {  
              sentencia = con.conectar.createStatement();  
               res=sentencia.executeQuery("select * from servicios_extra;");
              Vector columnas=new Vector();
            columnas.addElement("CV REGISTRO");
            columnas.addElement("CV EMPLEADO");
            columnas.addElement("CV SERVICIO");
            columnas.addElement("NOMBRE SERV.");            
            columnas.addElement("PRECIO");
            columnas.addElement("CANTIDAD");
            columnas.addElement("TOTAL");
            columnas.addElement("FECHA");
            columnas.addElement("HORA");
            Vector rows=new Vector();
            while(res.next()){  
                Vector filas=new Vector(); 
                filas.addElement(res.getInt("registro")); 
                filas.addElement(res.getString("clave_empleado")); 
                filas.addElement(res.getInt("clave_servicio")); 
                filas.addElement(res.getString("nombre_servicio")); 
                filas.addElement(res.getInt("precio")); 
                filas.addElement(res.getInt("cantidad"));
                filas.addElement(res.getInt("total")); 
                filas.addElement(res.getDate("fecha")); 
                filas.addElement(res.getTime("hora"));                
                rows.addElement(filas);
            } 
           datamodel=new DefaultTableModel(rows,columnas);         
        } catch (SQLException ex) {
            Logger.getLogger(Servicios.class.getName()).log(Level.SEVERE, null, ex);
        }
        return datamodel;
    }
    
}
